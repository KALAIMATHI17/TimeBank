const mongoose = require("mongoose");

const serviceSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },

    description: {
        type: String,
        required: true
    },

    hours: {
        type: Number,
        required: true
    },

    provider: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    },

    providerName: {
        type: String,
        required: true
    },

    status: {
        type: String,
        default: "Available"
    }
});

module.exports = mongoose.model("Service", serviceSchema);