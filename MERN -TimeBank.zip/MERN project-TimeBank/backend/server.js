const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const User = require("./models/User");
const Service = require("./models/Service");

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
    .then(() => {
        console.log("MongoDB Connected Successfully!");
    })
    .catch((error) => {
        console.log("MongoDB Connection Failed:", error.message);
    });


// HOME
app.get("/", (req, res) => {
    res.send("TimeBank Backend is Running!");
});


// REGISTER
app.post("/api/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;

        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).json({
                message: "Email already registered"
            });
        }

        const newUser = new User({
            name,
            email,
            password
        });

        await newUser.save();

        res.status(201).json({
            message: "User registered successfully!",
            user: {
                id: newUser._id,
                name: newUser.name,
                email: newUser.email,
                timeBalance: newUser.timeBalance
            }
        });

    } catch (error) {
        res.status(500).json({
            message: "Registration failed",
            error: error.message
        });
    }
});


// LOGIN
app.post("/api/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        const user = await User.findOne({ email });

        if (!user) {
            return res.status(400).json({
                message: "User not found"
            });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.status(400).json({
                message: "Invalid password"
            });
        }

        res.json({
            message: "Login successful!",
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                timeBalance: user.timeBalance
            }
        });

    } catch (error) {
        res.status(500).json({
            message: "Login failed",
            error: error.message
        });
    }
});


// GET ALL SERVICES
app.get("/api/services", async (req, res) => {
    try {
        const services = await Service.find();
        res.json(services);
    } catch (error) {
        console.error(error);
        res.json([]);
    }
});

// ADD SERVICE
app.post("/api/services", async (req, res) => {
    try {
        const {
            title,
            description,
            hours,
            provider,
            providerName
        } = req.body;

        const service = new Service({
            title,
            description,
            hours,
            provider,
            providerName
        });

        await service.save();

        res.status(201).json({
            message: "Service added successfully!",
            service
        });

    } catch (error) {
        res.status(500).json({
            message: "Failed to add service",
            error: error.message
        });
    }
});


// BOOK SERVICE
app.post("/api/services/:id/book", async (req, res) => {
    try {
        const { userId } = req.body;

        const service = await Service.findById(req.params.id);

        if (!service) {
            return res.status(404).json({
                message: "Service not found"
            });
        }

        if (service.status !== "Available") {
            return res.status(400).json({
                message: "Service is no longer available"
            });
        }

        if (service.provider.toString() === userId) {
            return res.status(400).json({
                message: "You cannot book your own service"
            });
        }

        const requester = await User.findById(userId);
        const provider = await User.findById(service.provider);

        if (!requester || !provider) {
            return res.status(404).json({
                message: "User not found"
            });
        }

        if (requester.timeBalance < service.hours) {
            return res.status(400).json({
                message: "Not enough time credits"
            });
        }

        requester.timeBalance -= service.hours;
        provider.timeBalance += service.hours;

        await requester.save();
        await provider.save();

        service.status = "Booked";
        await service.save();

        res.json({
            message: "Service booked successfully!",
            balance: requester.timeBalance
        });

    } catch (error) {
        res.status(500).json({
            message: "Booking failed",
            error: error.message
        });
    }
});

// DELETE a service (only its creator can delete it)
app.delete("/api/services/:id", async (req, res) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      return res.status(400).json({ message: "userId is required." });
    }

    const service = await Service.findById(req.params.id);
    if (!service) {
      return res.status(404).json({ message: "Service not found." });
    }

    if (String(service.provider) !== String(userId)) {
      return res.status(403).json({ message: "You can only delete your own service." });
    }

    await service.deleteOne();
    res.json({ message: "Service deleted successfully." });
  } catch (err) {
    if (err.name === "CastError") {
      return res.status(404).json({ message: "Service not found." });
    }
    console.error(err);
    res.status(500).json({ message: "Server error while deleting service." });
  }
});
app.listen(process.env.PORT, () => {
    console.log(`Server running on port ${process.env.PORT}`);
});