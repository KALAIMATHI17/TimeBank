import { useState } from "react";
import timebank from "./assets/timebank.png";
/* ---------- LANDING ---------- */
export function Landing({ go }) {
  const features = [
    ["⏱", "Time Credits", "Every hour you give earns an hour you can spend. No money involved."],
    ["🔄", "Skill Exchange", "Teach guitar, get help with maths, trade what you know."],
    ["🤝", "Trusted Community", "Real members, fair trades, one hour is always one hour."],
  ];
  return (
    <>
      <section className="hero">
        <div>
          <h1>Your Time Is Your Currency</h1>
          <p className="lead">TimeBank lets neighbours and classmates swap skills by the hour. Offer what you're good at, then spend your credits on what you need.</p>
          <div className="row">
            <button className="btn btn-primary" onClick={() => go("register")}>Get Started</button>
            <button className="btn btn-ghost" onClick={() => go("explore")}>Explore Services</button>
          </div>
        </div>
        <div className="visual">
          <div className="glass float-card c1"><b>🎸 Guitar lesson</b><span>1 hour · Priya</span></div>
          <div className="glass float-card c2"><b>📐 Maths tutoring</b><span>2 hours · Arjun</span></div>
          <div className="glass float-card c3"><b>🍳 Cooking class</b><span>1 hour · Meera</span></div>
          <div className="logo-center">
    <img
      src={timebank}
      alt="TimeBank logo"
    />
  </div>
        </div>
      </section>
      <section className="grid3">
        {features.map(([icon, title, text]) => (
          <div className="card" key={title}>
            <div className="icon-box">{icon}</div>
            <h3>{title}</h3>
            <p className="muted">{text}</p>
          </div>
        ))}
      </section>
    </>
  );
}

/* ---------- LOGIN + REGISTER ---------- */
export function AuthPage({ mode, onSubmit, loading, go }) {
  const isReg = mode === "register";
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [show, setShow] = useState(false);
  const [errs, setErrs] = useState({});

  const change = (e) => setF({ ...f, [e.target.name]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (isReg && f.name.trim().length < 2) er.name = "Please enter your name.";
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = "Enter a valid email address.";
    if (f.password.length < 6) er.password = "Use at least 6 characters.";
    setErrs(er);
    if (Object.keys(er).length === 0) onSubmit(f);
  };

  return (
    <div className="auth-wrap">
      <form className="card auth" onSubmit={submit} noValidate>
        <div className="icon-box">{isReg ? "✨" : "👋"}</div>
        <h2>{isReg ? "Create your account" : "Welcome back"}</h2>
        <p className="muted">{isReg ? "Join TimeBank and start trading hours." : "Log in to see your time balance."}</p>

        {isReg && (
          <label>Name
            <input name="name" value={f.name} onChange={change} placeholder="Your full name" />
            {errs.name && <small className="err">{errs.name}</small>}
          </label>
        )}
        <label>Email
          <input name="email" type="email" value={f.email} onChange={change} placeholder="you@example.com" />
          {errs.email && <small className="err">{errs.email}</small>}
        </label>
        <label>Password
          <div className="pw">
            <input name="password" type={show ? "text" : "password"} value={f.password} onChange={change} placeholder="At least 6 characters" />
            <button type="button" className="eye" onClick={() => setShow(!show)}>{show ? "Hide" : "Show"}</button>
          </div>
          {errs.password && <small className="err">{errs.password}</small>}
        </label>

        <button className="btn btn-primary full" disabled={loading}>
          {loading ? <span className="spinner" /> : isReg ? "Register" : "Log in"}
        </button>
        <p className="muted center">
          {isReg ? "Already a member? " : "New to TimeBank? "}
          <a onClick={() => go(isReg ? "login" : "register")}>{isReg ? "Log in" : "Register"}</a>
        </p>
      </form>
    </div>
  );
}

/* ---------- DASHBOARD ---------- */
export function Dashboard({ user, stats, go }) {
  const cards = [
    ["🛠", "Services Offered", stats.offered],
    ["📅", "Services Booked", stats.booked],
    ["📈", "Hours Earned", stats.earned],
    ["📉", "Hours Spent", stats.spent],
  ];
  return (
    <>
      <h2 className="page-title">Welcome, {user.name} 👋</h2>
      <div className="balance">
        <span>Your time balance</span>
        <strong>{user.timeBalance} Hours Available</strong>
      </div>
      <div className="grid4">
        {cards.map(([icon, label, value]) => (
          <div className="card stat" key={label}>
            <div className="icon-box">{icon}</div>
            <strong>{value}</strong>
            <span className="muted">{label}</span>
          </div>
        ))}
      </div>
      <h3 className="section">Quick actions</h3>
      <div className="grid3">
        <button className="card action" onClick={() => go("offer")}>➕ <b>Offer a Service</b><span className="muted">Share a skill and earn hours</span></button>
        <button className="card action" onClick={() => go("explore")}>🔍 <b>Find Services</b><span className="muted">Spend your hours on something new</span></button>
        <button className="card action" onClick={() => go("activity")}>🧾 <b>My Activity</b><span className="muted">See what you've given and received</span></button>
      </div>
    </>
  );
}

/* ---------- EXPLORE ---------- */
export function Explore({ services, loading, user, bookingId, onBook, onDelete, deletingId, go, isMine, isBooked }) {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");

  const shown = services.filter((s) => {
    const text = (s.title + " " + s.description + " " + s.providerName).toLowerCase();
    const matches = text.includes(q.toLowerCase());
    const status = filter === "all" || (filter === "available" ? !isBooked(s) : isBooked(s));
    return matches && status;
  });

  return (
    <>
      <div className="head-row">
        <h2 className="page-title">Explore services</h2>
        <button className="btn btn-primary small" onClick={() => go(user ? "offer" : "login")}>+ Offer a service</button>
      </div>
      <div className="toolbar">
        <input className="search" placeholder="🔍  Search by title, description or provider" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="pills">
          {["all", "available", "booked"].map((k) => (
            <button key={k} className={"pill " + (filter === k ? "on" : "")} onClick={() => setFilter(k)}>{k[0].toUpperCase() + k.slice(1)}</button>
          ))}
        </div>
      </div>

      {loading && <div className="grid3">{[1, 2, 3].map((i) => <div key={i} className="card skeleton" />)}</div>}

      {!loading && shown.length === 0 && (
        <div className="empty">
          <div className="orb small-orb">🌱</div>
          <h3>{services.length === 0 ? "No services yet" : "Nothing matches your search"}</h3>
          <p className="muted">{services.length === 0 ? "Be the first to offer a skill to the community." : "Try a different word or filter."}</p>
          {services.length === 0 && <button className="btn btn-primary" onClick={() => go(user ? "offer" : "login")}>Offer a service</button>}
        </div>
      )}

      <div className="grid3">
        {!loading && shown.map((s) => {
          const booked = isBooked(s);
          const own = user && isMine(s);
          return (
            <div className="card service" key={s._id}>
              <div className="head-row">
                <span className={"badge " + (booked ? "booked" : "ok")}>{booked ? "Booked" : "Available"}</span>
                <span className="chip">⏱ {s.hours}h</span>
              </div>
              <h3>{s.title}</h3>
              <p className="muted desc">{s.description}</p>
              <div className="provider"><span className="avatar">{(s.providerName || "?")[0].toUpperCase()}</span>{s.providerName}</div>
              {own ? (
                <>
                  <button className="btn btn-ghost full" disabled>Your service</button>
                  <button className="btn btn-danger full" disabled={deletingId === s._id} onClick={() => onDelete(s)}>
                    {deletingId === s._id ? <span className="spinner" /> : "🗑 Delete Service"}
                  </button>
                </>
              ) : (
                <button
                  className="btn btn-primary full"
                  disabled={booked || bookingId === s._id}
                  onClick={() => (user ? onBook(s) : go("login"))}
                >
                  {bookingId === s._id ? <span className="spinner" /> : booked ? "Already booked" : "Book Service"}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}

/* ---------- OFFER ---------- */
export function Offer({ onSubmit, onCancel, loading }) {
  const [f, setF] = useState({ title: "", description: "", hours: 1 });
  const [err, setErr] = useState("");
  const change = (e) => setF({ ...f, [e.target.name]: e.target.value });
  const submit = (e) => {
    e.preventDefault();
    if (f.title.trim().length < 3) return setErr("Give your service a title (3+ characters).");
    if (f.description.trim().length < 10) return setErr("Describe it in at least 10 characters.");
    if (!(Number(f.hours) > 0)) return setErr("Hours must be more than 0.");
    setErr("");
    onSubmit(f);
  };
  return (
    <div className="auth-wrap">
      <form className="card auth wide" onSubmit={submit}>
        <div className="icon-box">🛠</div>
        <h2>Offer a service</h2>
        <p className="muted">Tell the community what you can do.</p>
        <label>Service title<input name="title" value={f.title} onChange={change} placeholder="e.g. Beginner guitar lesson" /></label>
        <label>Description<textarea name="description" rows="4" value={f.description} onChange={change} placeholder="What will you help with?" /></label>
        <label>Hours required<input name="hours" type="number" min="1" step="1" value={f.hours} onChange={change} /></label>
        {err && <small className="err">{err}</small>}
        <div className="row">
          <button className="btn btn-primary" disabled={loading}>{loading ? <span className="spinner" /> : "Publish service"}</button>
          <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
}

/* ---------- PROFILE ---------- */
export function Profile({ user, onLogout }) {
  return (
    <div className="auth-wrap">
      <div className="card auth wide center">
        <span className="avatar big">{user.name[0].toUpperCase()}</span>
        <h2>{user.name}</h2>
        <p className="muted">{user.email}</p>
        <div className="info">
          <div><span className="muted">Time balance</span><b>{user.timeBalance} hours</b></div>
          <div><span className="muted">Email</span><b>{user.email}</b></div>
          <div><span className="muted">Account ID</span><b className="small-id">{user.id}</b></div>
        </div>
        <button className="btn btn-ghost full" onClick={onLogout}>Log out</button>
      </div>
    </div>
  );
}

/* ---------- ACTIVITY ---------- */
export function Activity({ items, go }) {
  return (
    <>
      <h2 className="page-title">My activity</h2>
      {items.length === 0 ? (
        <div className="empty">
          <div className="orb small-orb">🧾</div>
          <h3>No activity yet</h3>
          <p className="muted">Book or offer a service and it will show up here.</p>
          <button className="btn btn-primary" onClick={() => go("explore")}>Find services</button>
        </div>
      ) : (
        <div className="list">
          {items.map((a, i) => (
            <div className="card row-card" key={i}>
              <div className="icon-box">{a.type === "booked" ? "📥" : "📤"}</div>
              <div className="grow"><b>{a.title}</b><div className="muted">{a.note}</div></div>
              <span className={"amount " + (a.type === "booked" ? "minus" : "plus")}>{a.type === "booked" ? "-" : "+"}{a.hours}h</span>
            </div>
          ))}
        </div>
      )}
    </>
  );
}