import { useState, useEffect } from "react";
import "./index.css";
import {
  Landing,
  AuthPage,
  Dashboard,
  Explore,
  Offer,
  Profile,
  Activity
} from "./Pages";

const API = "http://localhost:5000";

// Backend request helper
async function request(path, options = {}) {
  let res;

  try {
    res = await fetch(API + path, {
      headers: {
        "Content-Type": "application/json",
      },
      ...options,
    });
  } catch {
    throw new Error(
      "Cannot reach the server. Is the backend running on port 5000?"
    );
  }

  let data = {};

  try {
    data = await res.json();
  } catch {
    // Empty response
  }

  if (!res.ok) {
    throw new Error(
      data.message || data.error || "Something went wrong"
    );
  }

  return data;
}


// Get previously logged-in user
const saved = JSON.parse(
  localStorage.getItem("tb_user") || "null"
);


export default function App() {

  const [page, setPage] = useState(
    saved ? "dashboard" : "landing"
  );

  const [user, setUser] = useState(saved);

  const [services, setServices] = useState([]);

  const [loading, setLoading] = useState(false);

  const [listLoading, setListLoading] = useState(false);

  const [bookingId, setBookingId] = useState(null);

  const [deletingId, setDeletingId] = useState(null);

  const [toast, setToast] = useState(null);

  const [menu, setMenu] = useState(false);

  const [bookings, setBookings] = useState([]);


  // Toast notification
  const notify = (msg, type = "success") => {

    setToast({
      msg,
      type
    });

    setTimeout(() => {
      setToast(null);
    }, 3500);
  };


  // Page navigation
  const go = (p) => {

    setPage(p);

    setMenu(false);

    window.scrollTo(0, 0);
  };


  // Load services
  const loadServices = async () => {

    setListLoading(true);

    try {

      const data = await request("/api/services");

      setServices(
        Array.isArray(data)
          ? data
          : data.services || []
      );

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setListLoading(false);

    }
  };


  // IMPORTANT:
  // Load services only AFTER user is logged in
  useEffect(() => {

    if (user) {
      loadServices();
    }

  }, [user]);


  // Load local bookings
  useEffect(() => {

    if (user) {

      const savedBookings = JSON.parse(
        localStorage.getItem(
          "tb_bookings_" + user.id
        ) || "[]"
      );

      setBookings(savedBookings);

    }

  }, [user]);


  // Save logged-in user
  const saveUser = (u) => {

    setUser(u);

    localStorage.setItem(
      "tb_user",
      JSON.stringify(u)
    );

  };


  // REGISTER
  const handleRegister = async (f) => {

    setLoading(true);

    try {

      await request("/api/register", {
        method: "POST",

        body: JSON.stringify({
          name: f.name,
          email: f.email,
          password: f.password,
        }),
      });

      notify(
        "Account created! Please log in."
      );

      go("login");

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setLoading(false);

    }
  };


  // LOGIN
  const handleLogin = async (f) => {

    setLoading(true);

    try {

      const data = await request("/api/login", {
        method: "POST",

        body: JSON.stringify({
          email: f.email,
          password: f.password,
        }),
      });


      const u = data.user || data;


      saveUser({
        id: u._id || u.id,
        name: u.name,
        email: u.email,
        timeBalance: u.timeBalance ?? 0,
      });


      notify(
        "Welcome back, " + u.name + "!"
      );

      go("dashboard");

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setLoading(false);

    }
  };


  // LOGOUT
  const handleLogout = () => {

    localStorage.removeItem("tb_user");

    setUser(null);

    setBookings([]);

    notify("You have been logged out.");

    go("landing");

  };


  // BOOK SERVICE
  const handleBook = async (s) => {

    setBookingId(s._id);

    try {

      const data = await request(
        "/api/services/" + s._id + "/book",
        {
          method: "POST",

          body: JSON.stringify({
            userId: user.id,
          }),
        }
      );


      const fromServer =
        data.timeBalance ??
        data.balance ??
        data.user?.timeBalance;


      saveUser({
        ...user,

        timeBalance:
          fromServer ??
          user.timeBalance - s.hours,
      });


      const next = [
        {
          id: s._id,
          title: s.title,
          hours: s.hours,
          date: new Date().toLocaleDateString(),
        },

        ...bookings,
      ];


      setBookings(next);


      localStorage.setItem(
        "tb_bookings_" + user.id,
        JSON.stringify(next)
      );


      await loadServices();


      notify(
        'Booked "' + s.title + '"!'
      );

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setBookingId(null);

    }
  };


  // OFFER SERVICE
  const handleOffer = async (f) => {

    setLoading(true);

    try {

      await request("/api/services", {

        method: "POST",

        body: JSON.stringify({

          title: f.title,

          description: f.description,

          hours: Number(f.hours),

          provider: user.id,

          providerName: user.name,

        }),

      });


      await loadServices();


      notify(
        "Your service is now live!"
      );


      go("explore");

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setLoading(false);

    }
  };


  // DELETE SERVICE
  const handleDelete = async (s) => {

    if (
      !window.confirm(
        "Are you sure you want to delete this service?"
      )
    ) {
      return;
    }


    setDeletingId(s._id);


    try {

      await request(
        "/api/services/" + s._id,
        {
          method: "DELETE",

          body: JSON.stringify({
            userId: user.id,
          }),
        }
      );


      await loadServices();


      notify(
        "Service deleted."
      );

    } catch (e) {

      notify(e.message, "error");

    } finally {

      setDeletingId(null);

    }
  };


  // Check whether service belongs to current user
  const isMine = (s) => {

    return (
      String(
        s.provider?._id ||
        s.provider
      ) === String(user?.id)
    );

  };


  // Check whether service is booked
  const isBooked = (s) => {

    return (
      s.status &&
      s.status.toLowerCase() !== "available"
    );

  };


  // My services
  const mine = services.filter(
    isMine
  );


  // Dashboard statistics
  const stats = {

    offered: mine.length,

    booked: bookings.length,

    earned: mine
      .filter(isBooked)
      .reduce(
        (total, service) =>
          total + Number(service.hours),
        0
      ),

    spent: bookings
      .reduce(
        (total, booking) =>
          total + Number(booking.hours),
        0
      ),

  };


  // Activity
  const activity = [

    ...bookings.map((b) => ({

      type: "booked",

      title: b.title,

      hours: b.hours,

      note:
        "Booked on " +
        b.date,

    })),

    ...mine.map((s) => ({

      type: "offered",

      title: s.title,

      hours: s.hours,

      note: isBooked(s)
        ? "Booked by someone"
        : "Waiting for a booking",

    })),

  ];


  // Navigation links
  const links = [

    ["dashboard", "Dashboard"],

    ["explore", "Explore"],

    ["offer", "Offer"],

    ["activity", "Activity"],

    ["profile", "Profile"],

  ];


  const protectedPage = [

    "dashboard",

    "explore",

    "offer",

    "profile",

    "activity",

  ].includes(page);


  const current =
    !user && protectedPage
      ? "login"
      : page;


  return (

    <div className="app">


      {/* NAVBAR */}

      <nav className="nav">

        <div
          className="logo"
          onClick={() =>
            go(
              user
                ? "dashboard"
                : "landing"
            )
          }
        >

          <span className="logo-mark">
            ⏳
          </span>

          TimeBank

        </div>


        <button
          className="burger"
          onClick={() =>
            setMenu(!menu)
          }
          aria-label="Menu"
        >
          ☰
        </button>


        <div
          className={
            "nav-links " +
            (menu ? "open" : "")
          }
        >

          {user ? (

            <>

              {links.map(
                ([key, label]) => (

                  <button
                    key={key}
                    className={
                      "nav-link " +
                      (
                        current === key
                          ? "active"
                          : ""
                      )
                    }
                    onClick={() =>
                      go(key)
                    }
                  >
                    {label}
                  </button>

                )
              )}


              <span className="chip">
                ⏱ {user.timeBalance}h
              </span>

            </>

          ) : (

            <>

              <button
                className="nav-link"
                onClick={() =>
                  go("explore")
                }
              >
                Explore
              </button>


              <button
                className="nav-link"
                onClick={() =>
                  go("login")
                }
              >
                Log in
              </button>


              <button
                className="btn btn-primary small"
                onClick={() =>
                  go("register")
                }
              >
                Get started
              </button>

            </>

          )}

        </div>

      </nav>


      {/* MAIN CONTENT */}

      <main
        className="container"
        key={current}
      >

        {current === "landing" && (

          <Landing
            go={go}
          />

        )}


        {current === "register" && (

          <AuthPage
            mode="register"
            onSubmit={handleRegister}
            loading={loading}
            go={go}
          />

        )}


        {current === "login" && (

          <AuthPage
            mode="login"
            onSubmit={handleLogin}
            loading={loading}
            go={go}
          />

        )}


        {current === "dashboard" && (

          <Dashboard
            user={user}
            stats={stats}
            go={go}
          />

        )}


        {current === "explore" && (

          <Explore
            services={services}
            loading={listLoading}
            user={user}
            bookingId={bookingId}
            onBook={handleBook}
            onDelete={handleDelete}
            deletingId={deletingId}
            go={go}
            isMine={isMine}
            isBooked={isBooked}
          />

        )}


        {current === "offer" && (

          <Offer
            onSubmit={handleOffer}
            onCancel={() =>
              go("explore")
            }
            loading={loading}
          />

        )}


        {current === "profile" && (

          <Profile
            user={user}
            onLogout={handleLogout}
          />

        )}


        {current === "activity" && (

          <Activity
            items={activity}
            go={go}
          />

        )}

      </main>


      {/* TOAST */}

      {toast && (

        <div
          className={
            "toast " +
            toast.type
          }
        >

          {toast.type === "error"
            ? "⚠️"
            : "✅"}

          {" "}

          {toast.msg}

        </div>

      )}

    </div>

  );
}